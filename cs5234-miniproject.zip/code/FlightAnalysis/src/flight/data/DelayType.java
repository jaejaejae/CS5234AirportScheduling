package flight.data;

public enum DelayType {
	NoDelay, ActualDelay, CustomDelay;
}
